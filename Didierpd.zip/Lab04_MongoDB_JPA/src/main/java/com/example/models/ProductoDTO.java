package com.example.models;



public class ProductoDTO {

    private String nombre;

    private String marca;

    private String fechaCompra;
    public ProductoDTO() {}
    public String getNombre() { return nombre; }
    public void setNombre(String value) { this.nombre = value; }
    public String getMarca() { return marca; }
    public void setMarca(String value) { this.marca = value; }
    public String getFechaCompra() { return fechaCompra; }
    public void setFechaCompra(String value) { this.fechaCompra = value; }

}
