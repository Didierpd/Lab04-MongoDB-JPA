#!/usr/bin/env python3
"""Creates identifiable test records; does not delete or replace existing records."""
import argparse,json,urllib.request,urllib.error,urllib.parse,uuid
from pathlib import Path

def run(base):
    checks=[]
    def check(label,ok):
        if not ok: raise AssertionError(label)
        checks.append(label);print('OK',label)
    def req(method,path,body=None,expected=200):
        data=None if body is None else json.dumps(body).encode()
        r=urllib.request.Request(base.rstrip('/')+path,data=data,method=method,headers={'Content-Type':'application/json'})
        try:
            with urllib.request.urlopen(r,timeout=30) as res: status=res.status;value=json.load(res)
        except urllib.error.HTTPError as e: status=e.code;value=json.load(e)
        check(method+' '+path+' → '+str(expected),status==expected)
        return value
    token=uuid.uuid4().hex[:10]
    p=req('POST','/products',{'nombre':'Portátil-'+token,'marca':'Laboratorio','fechaCompra':'2026-11-08'},201)
    check('Producto con id alfanumérico',isinstance(p['id'],str) and len(p['id'])==24)
    check('Fecha ISO conservada',p['fechaCompra']=='2026-11-08')
    def payload(name): return {'name':name,'surname':'Ensayo-'+token,'age':20,'telephone':'7659675','cellphone':'3002345436','address':'Dirección de prueba','city':'Bogotá','country':'Colombia','productoId':p['id']}
    ana=payload('Ana-'+token);ana['vehicle']={'plate':'TRE-465','brand':'BMW','modelYear':2024}
    a=req('POST','/competitors/vehicle',ana,201)
    check('Vehículo embebido devuelto',a['vehicle']['plate']=='TRE-465')
    check('Producto asociado devuelto',a['producto']['id']==p['id'])
    check('Fechas de auditoría presentes',bool(a['createdAt']) and bool(a['updatedAt']))
    b=req('POST','/competitors/add',payload('Bruno-'+token),201)
    c=req('POST','/competitors',payload('Alberto-'+token),201)
    rows=req('GET','/competitors');ids={x['id'] for x in rows}
    check('Tres competidores consultables',all(x['id'] in ids for x in (a,b,c)))
    check('Orden ascendente de apellidos',[x['surname'] for x in rows]==sorted(x['surname'] for x in rows))
    exact=req('GET','/competitors/'+urllib.parse.quote(ana['name']))
    check('Consulta con parámetro exacto',len(exact)==1 and exact[0]['id']==a['id'])
    check('Consulta inexistente devuelve lista vacía',req('GET','/competitors/NoExiste-'+token)==[])
    names=req('GET','/competitors/names/start-with-a')
    check('Filtro devuelve solo nombres con A',all(isinstance(n,str) and n.startswith('A') for n in names))
    check('Filtro incluye Ana y Alberto y excluye Bruno',a['name'] in names and c['name'] in names and b['name'] not in names)
    products=req('GET','/products');check('Lista de productos persistidos',any(x['id']==p['id'] for x in products))
    check('Fecha ISO estable al releer MongoDB',next(x for x in products if x['id']==p['id'])['fechaCompra']=='2026-11-08')
    baseline=len(rows)
    missing=payload('Inválido-'+token);missing.pop('productoId');req('POST','/competitors/add',missing,400)
    invalid=payload('Inválido-'+token);invalid['productoId']='000000000000000000000000';req('POST','/competitors/add',invalid,400)
    invalid=payload('Inválido-'+token);invalid['productoId']='xx';req('POST','/competitors/add',invalid,400)
    invalid=payload('Inválido-'+token);invalid['age']=-1;req('POST','/competitors/add',invalid,400)
    req('POST','/competitors/vehicle',payload('Inválido-'+token),400)
    req('POST','/products',{'nombre':'Inválido','marca':'Prueba','fechaCompra':'2025-02-29'},400)
    req('POST','/products',{'nombre':'   ','marca':'Prueba','fechaCompra':'2026-11-08'},400)
    check('Rechazos no insertaron competidores',len(req('GET','/competitors'))==baseline)
    report={'base':base,'checks':len(checks),'product_id':p['id'],'competitor_ids':[a['id'],b['id'],c['id']],'names':[a['name'],b['name'],c['name']],'note':'Registros de prueba conservados para revisar persistencia.'}
    print(json.dumps(report,ensure_ascii=False,indent=2));return report
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('base',nargs='?',default='http://127.0.0.1:8082');ap.add_argument('--report');args=ap.parse_args()
    result=run(args.base)
    if args.report: Path(args.report).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
