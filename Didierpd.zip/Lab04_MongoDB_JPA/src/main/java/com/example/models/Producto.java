package com.example.models;

import javax.persistence.*;
import org.eclipse.persistence.nosql.annotations.*;

@Entity
@NoSql(dataType="PRODUCTO", dataFormat=DataFormatType.MAPPED)
public class Producto {
    @Id @GeneratedValue @Field(name="_id")
    private String id;

    private String nombre;

    private String marca;
    // Store midnight UTC without provider truncation in the host time zone.
    @Temporal(TemporalType.TIMESTAMP)
    private java.util.Date fechaCompra;
    public Producto() {}
    public String getId() { return id; }
    public void setId(String value) { this.id = value; }
    public String getNombre() { return nombre; }
    public void setNombre(String value) { this.nombre = value; }
    public String getMarca() { return marca; }
    public void setMarca(String value) { this.marca = value; }
    public java.util.Date getFechaCompra() { return fechaCompra; }
    public void setFechaCompra(java.util.Date value) { this.fechaCompra = value; }

}
