#!/usr/bin/env python3
"""Starts/restarts Java against a unique test database; requires a running MongoDB."""
import os,sys,json,subprocess,time,uuid,urllib.request,argparse
from pathlib import Path
import pruebas_http
ROOT=Path(__file__).resolve().parents[1]
java=os.environ.get('JAVA_CMD','java')
parser=argparse.ArgumentParser();parser.add_argument('--cloud',action='store_true');parser.add_argument('--local-port',default='27017');parser.add_argument('--java',default=java);args=parser.parse_args();java=args.java
base_uri=os.environ.get('MONGODB_URI' if args.cloud else 'MONGODB_TEST_URI')
if args.cloud and not base_uri: raise SystemExit('Configure MONGODB_URI antes de usar --cloud.')
if not base_uri: base_uri='mongodb://127.0.0.1:'+str(int(args.local_port))+'/'
env=os.environ.copy();env['MONGODB_URI']=base_uri;env['MONGODB_DATABASE']=os.environ.get('MONGODB_DATABASE','ArquiSW') if args.cloud else 'lab04_test_'+uuid.uuid4().hex[:12];env['PORT']=os.environ.get('TEST_PORT','18082');env['HOST']='127.0.0.1'
base='http://127.0.0.1:'+env['PORT'];out=ROOT/'docs'/('evidencia-cloud' if args.cloud else 'evidencia');out.mkdir(parents=True,exist_ok=True)
cp='target/classes'+os.pathsep+'target/test-classes'+os.pathsep+'target/dependency/*'
proc=None
log=(out/'servidor-pruebas.log').open('w')
def start():
 global proc
 proc=subprocess.Popen([java,'-cp',cp,'com.example.Main'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
 for _ in range(60):
  if proc.poll() is not None: raise RuntimeError('El servidor terminó; revisar servidor-pruebas.log')
  try:
   with urllib.request.urlopen(base+'/products',timeout=1) as res:
    if res.status==200: return
  except Exception: time.sleep(.5)
 raise RuntimeError('El servidor no inició en 30 segundos')
def stop():
 global proc
 if proc is not None:
  proc.terminate()
  try:proc.wait(timeout=15)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
  proc=None
try:
 start();result=pruebas_http.run(base)
 stop();start()
 with urllib.request.urlopen(base+'/competitors') as r: rows=json.load(r)
 assert all(i in {v['id'] for v in rows} for i in result['competitor_ids'])
 with urllib.request.urlopen(base+'/products') as r: products=json.load(r)
 assert next(p for p in products if p['id']==result['product_id'])['fechaCompra']=='2026-11-08'
 print('OK Persistencia y fecha ISO conservadas después de reiniciar la API')
 direct=subprocess.run([java,'-cp',cp,'com.example.persistence.MongoEvidence',result['competitor_ids'][0],result['product_id']],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 print(direct.stdout);assert direct.returncode==0,'Falló verificación BSON'
 (out/'documentos-bson.txt').write_text(direct.stdout)
 result.update({'restart':'PASS','bson':'PASS','database':env['MONGODB_DATABASE'],'cloud':'Ejecutado contra la URI configurada por el usuario' if args.cloud else 'No ejecutado: requiere credenciales de Atlas','java':subprocess.check_output([java,'-version'],stderr=subprocess.STDOUT,text=True).splitlines()[0]})
 (out/'resultado.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print('RESULTADO: '+str(result['checks'])+' comprobaciones HTTP + reinicio + BSON correctos.')
finally:
 stop();log.close()
