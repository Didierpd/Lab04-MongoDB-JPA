package com.example.services;

import com.example.models.CompetitorDTO;
import com.example.persistence.LabRepository;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.*;

@Path("/competitors")
@Produces(MediaType.APPLICATION_JSON)
public class CompetitorService {
    private final LabRepository repository = new LabRepository();
    @GET public Response getAll() { return Response.ok(repository.competitors(null)).build(); }
    @GET @Path("names/start-with-a")
    public Response namesWithA() { return Response.ok(repository.namesWithA()).build(); }
    @GET @Path("{name}")
    public Response byName(@PathParam("name") String name) { return Response.ok(repository.competitors(name)).build(); }
    @POST @Consumes(MediaType.APPLICATION_JSON)
    public Response create(CompetitorDTO dto) { return saved(dto,false); }
    @POST @Path("add") @Consumes(MediaType.APPLICATION_JSON)
    public Response add(CompetitorDTO dto) { return saved(dto,false); }
    @POST @Path("vehicle") @Consumes(MediaType.APPLICATION_JSON)
    public Response vehicle(CompetitorDTO dto) { return saved(dto,true); }
    private Response saved(CompetitorDTO dto, boolean requireVehicle) {
        Map<String,Object> value = repository.createCompetitor(dto,requireVehicle);
        return Response.status(Response.Status.CREATED).entity(value).build();
    }
}
