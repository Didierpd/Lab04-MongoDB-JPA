package com.example.persistence;
import com.mongodb.*;
import org.bson.Document;
/** Emits only a category/code; never includes the URI or a server exception message. */
public final class AtlasConnectionCheck {
 public static void main(String[] args) {
  java.util.logging.Logger.getLogger("org.mongodb.driver").setLevel(java.util.logging.Level.OFF);
  try (MongoClient client = new MongoClient(new MongoClientURI(System.getenv("MONGODB_URI"), MongoClientOptions.builder().serverSelectionTimeout(10000).connectTimeout(10000).socketTimeout(15000)))) {
   client.getDatabase("ArquiSW").runCommand(new Document("ping",1));
   System.out.println("CONNECTION_OK");
  } catch (Exception ex) {
   for (Throwable t=ex;t!=null;t=t.getCause()) {
    System.out.println("TYPE="+t.getClass().getSimpleName());
    if(t instanceof MongoException) System.out.println("CODE="+((MongoException)t).getCode());
   }
   System.exit(1);
  }
 }
}
