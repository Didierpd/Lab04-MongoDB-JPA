package com.example;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.jetty.server.*;
import org.eclipse.jetty.servlet.*;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.servlet.ServletContainer;

/** Embedded server: no GlassFish or externally managed persistence context required. */
public final class Main {
    public static void main(String[] args) throws Exception {
        Logger.getLogger("org.mongodb.driver").setLevel(Level.WARNING);
        String port = System.getenv("PORT"); if (port == null || port.isEmpty()) port = "8082";
        String host = System.getenv("HOST"); if (host == null || host.isEmpty()) host = "127.0.0.1";
        final Server server = new Server();
        ServerConnector connector = new ServerConnector(server); connector.setHost(host); connector.setPort(Integer.parseInt(port)); server.addConnector(connector);
        ServletContextHandler context = new ServletContextHandler(); context.setContextPath("/");
        ResourceConfig config = new ResourceConfig().packages("com.example.services");
        config.property("jersey.config.server.wadl.disableWadl",true);
        context.addServlet(new ServletHolder(new ServletContainer(config)),"/*"); server.setHandler(context);
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try { server.stop(); } catch (Exception ignored) { }
            PersistenceManager.getInstance().closeEntityManagerFactory();
        }));
        try {
            // Force a real read: the factory itself can initialize lazily.
            new com.example.persistence.LabRepository().products();
            server.start();
            System.out.println("Laboratorio disponible en http://"+host+":"+port+"/"); server.join();
        } catch (Exception ex) {
            PersistenceManager.getInstance().closeEntityManagerFactory();
            System.err.println("Inicio fallido. Revise MongoDB, MONGODB_URI, puerto y permisos. Tipo: "+ex.getClass().getSimpleName());
            System.exit(1);
        }
    }
}
