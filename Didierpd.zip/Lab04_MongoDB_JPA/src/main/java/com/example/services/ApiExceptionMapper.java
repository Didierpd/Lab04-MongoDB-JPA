package com.example.services;
import java.util.Collections;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.*;
import javax.ws.rs.ext.*;

@Provider
public class ApiExceptionMapper implements ExceptionMapper<Exception> {
    @Override public Response toResponse(Exception ex) {
        int status = ex instanceof WebApplicationException ? ((WebApplicationException)ex).getResponse().getStatus() : 500;
        String message = status < 500 ? ex.getMessage() : "No se pudo completar la operación de persistencia.";
        if (status >= 500) System.err.println("Fallo de petición: " + ex.getClass().getSimpleName());
        return Response.status(status).type(MediaType.APPLICATION_JSON).entity(Collections.singletonMap("error",message)).build();
    }
}
