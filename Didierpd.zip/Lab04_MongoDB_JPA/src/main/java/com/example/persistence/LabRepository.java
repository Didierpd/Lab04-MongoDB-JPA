package com.example.persistence;

import com.example.PersistenceManager;
import com.example.models.*;
import java.time.ZoneOffset;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.persistence.*;
import javax.ws.rs.BadRequestException;

/** Each write affects one root document; does not claim cross-document Mongo transactions. */
public class LabRepository {
    private <T> T run(boolean write, Function<EntityManager,T> task) {
        EntityManager em = PersistenceManager.getInstance().getEntityManagerFactory().createEntityManager();
        try {
            if (write) em.getTransaction().begin();
            T result = task.apply(em);
            if (write) em.getTransaction().commit();
            return result;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            throw ex;
        } finally { em.close(); }
    }
    public Map<String,Object> createProduct(ProductoDTO dto) {
        if (dto == null) throw new BadRequestException("Se requiere un cuerpo JSON.");
        final Producto p = new Producto();
        p.setNombre(Validation.text(dto.getNombre(), "nombre"));
        p.setMarca(Validation.text(dto.getMarca(), "marca")); p.setFechaCompra(Validation.date(dto.getFechaCompra()));
        // Map after commit: generated ObjectId is guaranteed to have been assigned.
        run(true, em -> { em.persist(p); return null; });
        return productView(p);
    }
    public Map<String,Object> createCompetitor(CompetitorDTO dto, boolean vehicleRequired) {
        Validation.competitor(dto, vehicleRequired);
        final Competitor c = new Competitor();
        c.setName(dto.getName()); c.setSurname(dto.getSurname()); c.setAge(dto.getAge());
        c.setAddress(dto.getAddress()); c.setCellphone(dto.getCellphone()); c.setCity(dto.getCity());
        c.setCountry(dto.getCountry()); c.setTelephone(dto.getTelephone()); c.setVehicle(dto.getVehicle());
        run(true, em -> {
            Producto product = em.find(Producto.class, dto.getProductoId());
            if (product == null) throw new BadRequestException("El producto asociado no existe.");
            c.setProducto(product); em.persist(c); return null;
        });
        return competitorView(c);
    }
    public List<Map<String,Object>> products() {
        return run(false, em -> em.createQuery("SELECT p FROM Producto p ORDER BY p.nombre ASC", Producto.class)
            .getResultList().stream().map(LabRepository::productView).collect(Collectors.toList()));
    }
    public List<Map<String,Object>> competitors(String name) {
        return run(false, em -> {
            TypedQuery<Competitor> q = name == null
                ? em.createQuery("SELECT c FROM Competitor c ORDER BY c.surname ASC", Competitor.class)
                : em.createQuery("SELECT c FROM Competitor c WHERE c.name = :name ORDER BY c.surname ASC", Competitor.class).setParameter("name", name);
            return q.getResultList().stream().map(LabRepository::competitorView).collect(Collectors.toList());
        });
    }
    public List<String> namesWithA() {
        // Query entities, then project names: NoSQL JPQL has more restrictions than relational JPQL.
        return run(false, em -> em.createQuery("SELECT c FROM Competitor c WHERE c.name LIKE :prefix ORDER BY c.name ASC", Competitor.class)
            .setParameter("prefix", "A%").getResultList().stream().map(Competitor::getName).collect(Collectors.toList()));
    }
    private static Map<String,Object> productView(Producto p) {
        Map<String,Object> m = new LinkedHashMap<>(); m.put("id",p.getId()); m.put("nombre",p.getNombre()); m.put("marca",p.getMarca());
        m.put("fechaCompra",p.getFechaCompra().toInstant().atZone(ZoneOffset.UTC).toLocalDate().toString()); return m;
    }
    private static Map<String,Object> competitorView(Competitor c) {
        Map<String,Object> m = new LinkedHashMap<>();
        m.put("id",c.getId()); m.put("name",c.getName()); m.put("surname",c.getSurname()); m.put("age",c.getAge());
        m.put("telephone",c.getTelephone()); m.put("cellphone",c.getCellphone()); m.put("address",c.getAddress());
        m.put("city",c.getCity()); m.put("country",c.getCountry()); m.put("winner",c.isWinner());
        m.put("createdAt",c.getCreatedAt().toInstant().toString()); m.put("updatedAt",c.getUpdatedAt().toInstant().toString());
        m.put("vehicle",c.getVehicle()); m.put("producto",productView(c.getProducto())); return m;
    }
}
