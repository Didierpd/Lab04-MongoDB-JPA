# Laboratorio 04 — MongoDB con JPA y EclipseLink NoSQL

Proyecto basado en [gpedrazag/Lab-DespliegueCloud](https://github.com/gpedrazag/Lab-DespliegueCloud), commit `3cb56ba567de62a641adf75bc142bbca55a4d7c0`.
Implementación de la guía **lab04_MongoDB-2019-1.pdf**, incluidas sus cuatro actividades finales. Se conserva el dominio de competidores del laboratorio; es un proyecto independiente de Cursos Virtuales.

## Alcance y estado

- `Competitor`: `@Entity`, `@NoSql(MAPPED)`, ID String generado y fechas de auditoría.
- `Vehicle`: `@Embeddable`, guardado dentro del documento del competidor.
- `Producto`: `@Entity` independiente, colección `PRODUCTO`, atributos `nombre`, `marca` y `fechaCompra`.
- Cada competidor tiene exactamente **una referencia a un producto existente**, obligatoria por validación de la API, `optional=false` y callback de entidad.
- Listado de productos, listado de competidores ordenado, búsqueda exacta por nombre y nombres que empiezan por `A` mayúscula.
- Configuración local y por URI cloud, sin credenciales en el proyecto.

**Conexión cloud comprobada contra MongoDB Atlas real** en `cluster0.keens7w.mongodb.net`, base `ArquiSW`: 31 comprobaciones HTTP correctas, reinicio de API y lectura BSON verificados. Consultar [configuración de Atlas](docs/ATLAS.md) y [evidencia ejecutada](docs/VALIDACION.md).

## Requisitos

- JDK 8 actualizado (ejecución comprobada con Temurin 8u502). El código se compila a Java 8; también se compiló con JDK 21.
- Maven 3.8.6 o posterior.
- MongoDB Community en ejecución o un clúster Atlas configurado.
- Python 3 para las pruebas HTTP e integración (solo biblioteca estándar).

Versiones fijadas: EclipseLink y NoSQL **2.7.16**, driver MongoDB **3.12.14**, Jersey **2.41**, Jetty **9.4.57.v20241219**. Se evita mezclar EclipseLink 2.5.0 con 2.5.0-RC1 como ocurre en el ejemplo original. Esta solución mantiene la API JPA `javax.persistence`; el soporte MongoDB depende de la extensión de EclipseLink, no es portabilidad estándar de JPA.

## Ejecutar localmente

Desde la raíz del proyecto:

```bash
mvn clean package
# En otra terminal, iniciar una instalación MongoDB; no necesita mongosh para la API:
mkdir -p .data/mongo
mongod --dbpath .data/mongo --bind_ip 127.0.0.1 --port 27017
```

En la terminal de la aplicación:

```bash
export MONGODB_URI='mongodb://127.0.0.1:27017/ArquiSW'
export MONGODB_DATABASE='ArquiSW'
export PORT=8082
java -cp 'target/classes:target/dependency/*' com.example.Main
```

En Windows usar `;` entre los elementos del classpath:

```powershell
$env:MONGODB_URI='mongodb://127.0.0.1:27017/ArquiSW'
$env:MONGODB_DATABASE='ArquiSW'
$env:PORT='8082'
java -cp "target/classes;target/dependency/*" com.example.Main
```

Abrir `http://127.0.0.1:8082/` para consultar las rutas. El servidor se enlaza a localhost por defecto. `HOST` permite configurar la dirección si el despliegue lo requiere. La aplicación comprueba una lectura real de MongoDB antes de anunciar que está disponible. Detener con Ctrl+C cierra la fábrica JPA y el cliente Mongo.

En **este computador** se instaló MongoDB para las pruebas en `/home/didier1/Aplicaciones/mongodb-lab/bin/mongod`; se usó el puerto `27018` para no interferir con instalaciones normales. JDK 8 está en `/home/didier1/Aplicaciones/java8/`. Estas rutas son particulares de este equipo y no son requisitos del ZIP.

### NetBeans

Abrir el directorio con **File → Open Project** como proyecto Maven. Seleccionar un JDK compatible para la plataforma del proyecto y ejecutar **Clean and Build**. Configurar las variables de entorno antes de abrir el IDE y ejecutar la clase principal `com.example.Main`. Es un servidor embebido, no requiere registrar GlassFish. El formato Maven puede abrirse en NetBeans; la validación de esta entrega se hizo desde terminal, no mediante NetBeans 8.0.2.

## Recorrido completo (Postman o curl)

Importar `examples/Lab04_MongoDB.postman_collection.json`. La colección captura el `productoId` de la primera respuesta y lo utiliza en las solicitudes siguientes.

### 1. Crear el producto

```http
POST http://127.0.0.1:8082/products
Content-Type: application/json

{"nombre":"Portátil","marca":"Lenovo","fechaCompra":"2026-11-08"}
```

Devuelve **201** con `id`, `nombre`, `marca` y fecha ISO. Copiar **exactamente** el `id` devuelto; los identificadores generados por este proveedor se almacenan como String alfanumérico, por lo que debe conservarse su representación.

### 2. Crear competidor con producto y vehículo

```http
POST http://127.0.0.1:8082/competitors/vehicle
Content-Type: application/json

{
  "name":"Ana",
  "surname":"Pérez",
  "age":20,
  "telephone":"7659675",
  "cellphone":"3002345436",
  "address":"Dirección de ejemplo",
  "city":"Bogotá",
  "country":"Colombia",
  "productoId":"REEMPLAZAR_POR_ID_REAL",
  "vehicle":{"plate":"TRE-465","brand":"BMW","modelYear":2024}
}
```

La ruta `/competitors/vehicle` exige vehículo. Las rutas `/competitors/add` y `POST /competitors` permiten omitirlo; **las tres exigen producto**. Crear primero el producto permite que cada escritura JPA afecte un solo documento raíz, sin atribuir al adaptador transacciones multidocumento que no ofrece. Se puede asociar el mismo producto a más de un competidor; la consigna no exige exclusividad del producto, solo una asociación obligatoria por competidor. El mapeo es `@ManyToOne(optional=false)` sin cascada de alta ni eliminación.

### 3. Consultar

| Método | Ruta | Resultado |
| --- | --- | --- |
| GET | `/products` | Todos los productos, ordenados por nombre. |
| GET | `/competitors` | Competidores ordenados por apellido. |
| GET | `/competitors/Ana` | Coincidencia exacta del nombre mediante parámetro JPQL. |
| GET | `/competitors/names/start-with-a` | Lista de cadenas con los nombres que empiezan por `A` mayúscula. |

Ejemplo del último resultado: `["Alberto","Ana"]`. No se devuelven objetos completos en esa consulta. La consulta usa `LIKE :prefix` con `A%`; la proyección a nombres se hace en Java por las limitaciones JPQL de NoSQL. Una búsqueda sin coincidencias responde **200** y `[]`.

Errores de datos: **400** y JSON con `error`. Se rechazan producto ausente/inexistente, nombres vacíos, edad fuera de 0–120, fecha inválida y año de vehículo inválido. Fallos internos responden **500** con mensaje general, sin declarar una creación exitosa. JSON inválido produce 400 desde el proveedor JSON.

### 4. Inspeccionar MongoDB

Con mongosh conectado a la misma base:

```javascript
use ArquiSW
db.PRODUCTO.find()
db.COMPETITOR.find()
```

`COMPETITOR` contiene un campo `productoId` que referencia el `_id` del documento de `PRODUCTO`, y la información embebida del vehículo (este proveedor la representa en BSON como `VEHICLE: [{...}]`, un arreglo de un documento; en Java sigue siendo un único `@Embedded Vehicle`). Los nombres de campos automapeados pueden aparecer en mayúsculas; `productoId` y `_id` se fijan mediante anotaciones. No hay tabla SQL ni JOIN SQL. Las colecciones aparecen al persistir su primer documento; no se ejecuta `drop-and-create` al iniciar.

## Pruebas

```bash
mvn test
# Con la API ya en ejecución: inserta datos identificables y los conserva.
python3 scripts/pruebas_http.py http://127.0.0.1:8082
# Prueba integral: crea una base única lab04_test_*, arranca su propia API,
# comprueba HTTP, reinicia la API y lee directamente el BSON persistido.
mvn test-compile package
export MONGODB_TEST_URI='mongodb://127.0.0.1:27017/'
python3 scripts/pruebas_integracion.py
```

`JAVA_CMD` permite elegir el ejecutable Java y `TEST_PORT` el puerto (18082 por defecto). Las pruebas conservan sus documentos en una base aislada para revisar evidencia; no borran ni reemplazan datos previos. El runner de integración verifica datos reales, no un mock de MongoDB.

## Organización

```text
src/main/java/com/example/
  Main.java, PersistenceManager.java
  models/      Competitor, CompetitorDTO, Producto, ProductoDTO, Vehicle
  persistence/ LabRepository, Validation, MongoRuntime, UriMongoConnectionSpec
  services/    CompetitorService, ProductoService, InfoService, ApiExceptionMapper
src/main/resources/META-INF/persistence.xml   # mongoPU
src/test/       validaciones y verificador BSON de lectura
scripts/        pruebas y arranque portable
examples/       JSON y colección Postman
docs/           decisiones, Atlas y evidencia
```

`EntityManagerFactory` es compartida y se inicializa sincronizadamente; cada operación crea y cierra su propio `EntityManager`. Las altas manejan begin/commit/rollback para el ciclo de trabajo JPA, sin afirmar atomicidad entre documentos en este adaptador. No hay un EntityManager global cerrado por la primera petición.

`UriMongoConnectionSpec` adapta la fábrica de conexión de EclipseLink al cliente configurado por `MongoClientURI`: preserva SRV, TLS, autenticación y `authSource` para Atlas. Las consultas y escrituras del dominio se ejecutan con `EntityManager` y JPQL. La lectura con driver directo solo se usa para preparar la conexión y para evidencia de pruebas.

## Diferencias deliberadas respecto de la guía

1. Puerto coherente **8082** en todos los ejemplos; la guía mezcla 8080 y 8082.
2. `/add` se ofrece como alias y `/vehicle` se implementa explícitamente; no hay dos métodos Java con la misma firma.
3. Devuelve 201 solo tras confirmar la persistencia; no oculta errores devolviendo 200.
4. `Producto` es entidad independiente, no se confunde con el `Vehicle` embebido.
5. El año `345` del ejemplo se cambia por un año de vehículo válido; la fecha se recibe como ISO.
6. Se usa `@Field`/`@JoinField` para el documento NoSQL y no se configura JDBC/PostgreSQL.
7. Atlas se configura mediante variables privadas y fue verificado contra un clúster real; las claves se conservan solo en `.env`, excluido del ZIP.

## Entrega

El archivo `Didierpd.zip` contiene fuentes, configuración de ejemplo, instrucciones, pruebas, colección Postman y evidencia local. El código de `target/` se regenera con Maven. No se incluyen `.git`, `.env`, binarios antiguos de `lib/`, base de datos ni contraseñas.

El objetivo cloud quedó verificado y su evidencia está en `docs/evidencia-cloud/`. Subir el ZIP actualizado en Moodle; este proyecto no realiza esa carga automáticamente. En otro equipo se deberán configurar credenciales propias antes de repetir la prueba cloud.
