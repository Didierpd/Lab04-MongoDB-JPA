package com.example.models;



public class CompetitorDTO {

    private String name;

    private String surname;

    private Integer age;

    private String telephone;

    private String cellphone;

    private String address;

    private String city;

    private String country;

    private Vehicle vehicle;

    private String productoId;
    public CompetitorDTO() {}
    public String getName() { return name; }
    public void setName(String value) { this.name = value; }
    public String getSurname() { return surname; }
    public void setSurname(String value) { this.surname = value; }
    public Integer getAge() { return age; }
    public void setAge(Integer value) { this.age = value; }
    public String getTelephone() { return telephone; }
    public void setTelephone(String value) { this.telephone = value; }
    public String getCellphone() { return cellphone; }
    public void setCellphone(String value) { this.cellphone = value; }
    public String getAddress() { return address; }
    public void setAddress(String value) { this.address = value; }
    public String getCity() { return city; }
    public void setCity(String value) { this.city = value; }
    public String getCountry() { return country; }
    public void setCountry(String value) { this.country = value; }
    public Vehicle getVehicle() { return vehicle; }
    public void setVehicle(Vehicle value) { this.vehicle = value; }
    public String getProductoId() { return productoId; }
    public void setProductoId(String value) { this.productoId = value; }

}
