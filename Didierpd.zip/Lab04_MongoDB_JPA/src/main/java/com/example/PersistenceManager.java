package com.example;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.example.persistence.MongoRuntime;

/** One thread-safe factory, one EntityManager per repository operation. */
public final class PersistenceManager {
    private static final PersistenceManager INSTANCE = new PersistenceManager();
    private EntityManagerFactory emf;
    private PersistenceManager() {}
    public static PersistenceManager getInstance() { return INSTANCE; }
    public synchronized EntityManagerFactory getEntityManagerFactory() {
        if (emf == null || !emf.isOpen()) emf = Persistence.createEntityManagerFactory("mongoPU");
        return emf;
    }
    public synchronized void closeEntityManagerFactory() {
        try { if (emf != null && emf.isOpen()) emf.close(); }
        finally { emf = null; MongoRuntime.close(); }
    }
}
