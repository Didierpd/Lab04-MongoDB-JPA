#!/usr/bin/env python3
"""Load only known values from the private .env without executing shell commands."""
import argparse,os,shlex,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--diagnostico',action='store_true');ap.add_argument('--java',default=os.environ.get('JAVA_CMD','java'));args=ap.parse_args()
f=ROOT/'.env'
if not f.exists():raise SystemExit('Falta la configuración privada .env.')
env=os.environ.copy()
for line in f.read_text().splitlines():
 if '=' not in line or line.lstrip().startswith('#'):continue
 key,value=line.split('=',1)
 if key in ('MONGODB_URI','MONGODB_DATABASE'):
  parts=shlex.split(value)
  if len(parts)!=1:raise SystemExit('Formato .env no válido.')
  env[key]=parts[0]
if args.diagnostico:
 cmd=[args.java,'-cp','target/classes'+os.pathsep+'target/test-classes'+os.pathsep+'target/dependency/*','com.example.persistence.AtlasConnectionCheck']
 sys.exit(subprocess.run(cmd,cwd=ROOT,env=env).returncode)
cmd=[sys.executable,str(ROOT/'scripts/pruebas_integracion.py'),'--cloud','--java',args.java]
out=ROOT/'docs/evidencia-cloud';out.mkdir(parents=True,exist_ok=True)
with (out/'pruebas-http.txt').open('w') as log:r=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
print('ATLAS: pruebas correctas.' if r.returncode==0 else 'ATLAS: prueba fallida; revisar evidencia sin compartir credenciales.')
sys.exit(r.returncode)
