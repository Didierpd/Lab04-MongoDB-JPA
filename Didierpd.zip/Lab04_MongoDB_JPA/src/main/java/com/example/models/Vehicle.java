package com.example.models;

import javax.persistence.*;
import org.eclipse.persistence.nosql.annotations.*;

@Embeddable
@NoSql(dataFormat=DataFormatType.MAPPED)
public class Vehicle {

    private String plate;

    private String brand;

    private int modelYear;
    public Vehicle() {}
    public String getPlate() { return plate; }
    public void setPlate(String value) { this.plate = value; }
    public String getBrand() { return brand; }
    public void setBrand(String value) { this.brand = value; }
    public int getModelYear() { return modelYear; }
    public void setModelYear(int value) { this.modelYear = value; }

}
