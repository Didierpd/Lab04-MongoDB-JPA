package com.example.persistence;

import com.example.models.*;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeParseException;
import java.util.Date;
import javax.ws.rs.BadRequestException;
import org.bson.types.ObjectId;

public final class Validation {
    private Validation() {}
    public static String text(String value, String field) {
        if (value == null || value.trim().isEmpty() || value.trim().length() > 150)
            throw new BadRequestException(field + " es obligatorio (1–150 caracteres).");
        return value.trim();
    }
    public static String id(String value) {
        if (value == null || !ObjectId.isValid(value)) throw new BadRequestException("productoId debe ser un ObjectId válido.");
        return value;
    }
    public static Date date(String value) {
        try {
            if (value == null || !value.matches("\\d{4}-\\d{2}-\\d{2}")) throw new DateTimeParseException("Formato", "", 0);
            return Date.from(LocalDate.parse(value).atStartOfDay().toInstant(ZoneOffset.UTC));
        } catch (DateTimeParseException ex) { throw new BadRequestException("fechaCompra debe ser una fecha válida AAAA-MM-DD."); }
    }
    public static void competitor(CompetitorDTO dto, boolean requireVehicle) {
        if (dto == null) throw new BadRequestException("Se requiere un cuerpo JSON.");
        dto.setName(text(dto.getName(), "name")); dto.setSurname(text(dto.getSurname(), "surname"));
        if (dto.getAge() == null || dto.getAge() < 0 || dto.getAge() > 120)
            throw new BadRequestException("age debe estar entre 0 y 120.");
        id(dto.getProductoId());
        Vehicle v = dto.getVehicle();
        if (requireVehicle && v == null) throw new BadRequestException("vehicle es obligatorio en esta ruta.");
        if (v != null) {
            v.setPlate(text(v.getPlate(), "vehicle.plate")); v.setBrand(text(v.getBrand(), "vehicle.brand"));
            if (v.getModelYear() < 1886 || v.getModelYear() > LocalDate.now().getYear() + 1)
                throw new BadRequestException("vehicle.modelYear no es un año válido.");
        }
    }
}
