#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")/.."
if [[ -f .env ]]; then set -a; source .env; set +a; fi
if [[ ! -d target/dependency ]]; then mvn package; fi
exec "${JAVA_CMD:-java}" -cp 'target/classes:target/dependency/*' com.example.Main
