#!/usr/bin/env python3
"""Collect credentials locally, save private .env, optionally verify Atlas through JPA."""
import argparse,getpass,os,re,shlex,shutil,subprocess,sys,tempfile
from pathlib import Path
from urllib.parse import quote
ROOT=Path(__file__).resolve().parents[1]

def field(label,password=False,default=''):
    if os.environ.get('DISPLAY') and shutil.which('zenity'):
        if password:
            cmd=['zenity','--password','--title=Atlas · contraseña ACTUAL del usuario de base de datos']
        else:
            cmd=['zenity','--entry','--title=MongoDB Atlas · usuario de base de datos',
                 '--text='+label,'--entry-text='+default,'--width=520']
        result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True)
        if result.returncode: raise SystemExit('Configuración cancelada. No se guardaron credenciales nuevas.')
        return result.stdout.rstrip('\n')
    return getpass.getpass(label+': ') if password else (input(label+' ['+default+']: ').strip() or default)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--host',required=True);ap.add_argument('--usuario',default='');ap.add_argument('--database',default='ArquiSW')
    ap.add_argument('--probar',action='store_true');ap.add_argument('--java',default=os.environ.get('JAVA_CMD','java'));args=ap.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9.-]+\.mongodb\.net',args.host): raise SystemExit('Se requiere el hostname Atlas terminado en .mongodb.net.')
    if not re.fullmatch(r'[A-Za-z0-9_-]+',args.database): raise SystemExit('Nombre de base no válido.')
    user=field('Confirma el usuario de BASE DE DATOS de Atlas (no el correo de acceso).',default=args.usuario).strip()
    password=field('Contraseña actual del usuario de base de datos',password=True)
    if not user or not password: raise SystemExit('Usuario y contraseña son obligatorios. No se guardó configuración.')
    uri='mongodb+srv://'+quote(user,safe='')+':'+quote(password,safe='')+'@'+args.host+'/'+args.database+'?retryWrites=true&w=majority&authSource=admin&tls=true&appName=Lab04-MongoDB-JPA'
    config='MONGODB_URI='+shlex.quote(uri)+'\nMONGODB_DATABASE='+shlex.quote(args.database)+'\nPORT=8082\nHOST=127.0.0.1\n'
    fd,name=tempfile.mkstemp(prefix='.env.tmp.',dir=ROOT)
    try:
        with os.fdopen(fd,'w') as f: f.write(config)
        os.chmod(name,0o600);os.replace(name,ROOT/'.env')
    finally:
        if Path(name).exists(): Path(name).unlink()
    print('Configuración guardada en .env con permisos privados. No se muestra la contraseña.',flush=True)
    if args.probar:
        env=os.environ.copy();env['MONGODB_URI']=uri;env['MONGODB_DATABASE']=args.database
        print('Comprobando Atlas con los servicios JPA, reinicio y lectura BSON...',flush=True)
        out=ROOT/'docs/evidencia-cloud';out.mkdir(parents=True,exist_ok=True)
        with (out/'pruebas-http.txt').open('w') as log:
            result=subprocess.run([sys.executable,str(ROOT/'scripts/pruebas_integracion.py'),'--cloud','--java',args.java],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
        if result.returncode:
            print('La prueba no terminó correctamente. Revisar conectividad, usuario y permisos; la evidencia está en docs/evidencia-cloud/.',flush=True)
            return result.returncode
        print('ATLAS VERIFICADO: altas, consultas, validaciones, reinicio y BSON correctos.',flush=True)
    return 0
if __name__=='__main__': sys.exit(main())
