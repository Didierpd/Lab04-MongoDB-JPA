package com.example.persistence;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientURI;
import org.bson.Document;
import org.eclipse.persistence.internal.nosql.adapters.mongo.MongoCodecs;

/** Driver only bootstraps the EclipseLink adapter; repositories use EntityManager. */
public final class MongoRuntime {
    private static MongoClient client;
    private static String database;
    private MongoRuntime() {}
    public static synchronized MongoClient client() {
        if (client == null) {
            String uri = System.getenv("MONGODB_URI");
            if (uri == null || uri.trim().isEmpty()) uri = "mongodb://127.0.0.1:27017/ArquiSW";
            MongoClientURI parsed = new MongoClientURI(uri, MongoClientOptions.builder()
                .serverSelectionTimeout(10000).connectTimeout(10000).socketTimeout(15000)
                .codecRegistry(MongoCodecs.codecRegistry()));
            String override = System.getenv("MONGODB_DATABASE");
            database = override != null && !override.trim().isEmpty() ? override : parsed.getDatabase();
            if (database == null || database.trim().isEmpty()) database = "ArquiSW";
            MongoClient pending = new MongoClient(parsed);
            try { pending.getDatabase(database).runCommand(new Document("ping", 1)); }
            catch (RuntimeException ex) { pending.close(); throw new IllegalStateException("No se pudo conectar a MongoDB. Revise URI, red, TLS y permisos."); }
            client = pending;
        }
        return client;
    }
    public static synchronized String database() { client(); return database; }
    public static synchronized void close() { if (client != null) { client.close(); client = null; } }
}
