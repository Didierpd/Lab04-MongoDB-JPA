# Validación del laboratorio

Fecha: 8 de noviembre de 2026. Proyecto base: `gpedrazag/Lab-DespliegueCloud`, commit `3cb56ba567de62a641adf75bc142bbca55a4d7c0`.

## Ambiente

- Linux x86_64; servidor MongoDB Community **7.0.16**, instalación local en puerto **27018**.
- API ejecutada en **JDK 8u502**; compilación Maven con JDK 21 a bytecode Java 8.
- EclipseLink/NoSQL **2.7.16**; driver MongoDB **3.12.14**; Jersey **2.41**; Jetty **9.4.57.v20241219**.
- Pruebas HTTP en una base única `lab04_test_*`, conservada para inspección y separada de los datos del usuario. El runner detiene su propia API al terminar.

## Resultados

| Verificación | Resultado |
| --- | --- |
| `mvn -o -B -ntp package` | BUILD SUCCESS. |
| Validación de entradas JUnit | 10 pruebas, 0 fallos, 0 errores. |
| Altas y consultas HTTP | 31 comprobaciones correctas. |
| Reinicio de la API | Competidores y fecha de compra conservados. |
| Lectura directa BSON | Documentos `PRODUCTO` y `COMPETITOR`, referencia `productoId` y vehículo embebido confirmados. |
| Atlas | **PASS**: 31 comprobaciones HTTP, reinicio y BSON contra el clúster real. |
| NetBeans 8.0.2 | Apertura/ejecución no comprobadas; construcción verificada desde Maven. |

## Cobertura funcional

Las pruebas crean un producto, tres competidores (uno con vehículo), consultan todos los registros, comprueban el orden por apellido, la búsqueda exacta por nombre y el filtro de nombres con A. Rechazan producto ausente, mal formado o inexistente, edad negativa, vehículo omitido en `/vehicle`, fecha imposible y nombre de producto vacío. Comprueban que los rechazos no insertan competidores.

Se verifica la fecha ISO tanto al crear como al consultar desde MongoDB y después de reiniciar. `fechaCompra` se guarda con precisión temporal suficiente para evitar truncarla a la zona horaria del servidor; la API la expone como fecha `AAAA-MM-DD` en UTC.

La evidencia BSON confirma la representación real del proveedor: `_id` y `productoId` son String; `VEHICLE` es un arreglo de un documento embebido y no una colección independiente. No se exige BSON ObjectId cuando JPA usa un ID String.

## Reproducir

```bash
mvn clean package
# Iniciar MongoDB de prueba en otra terminal.
python3 scripts/pruebas_integracion.py --local-port 27018
# Para elegir JDK:
python3 scripts/pruebas_integracion.py --local-port 27018 --java /ruta/jdk8/bin/java
```

Para otro servidor local usar `MONGODB_TEST_URI`. Para Atlas seguir `ATLAS.md` y usar `--cloud`. No se incluyen credenciales. Los scripts generan `docs/evidencia/resultado.json`, `documentos-bson.txt` y el registro del servidor de pruebas. Las credenciales de Atlas no deben añadirse al ZIP ni a los registros de evidencia.

## Correspondencia con la actividad

1. **Crear Producto:** `models/Producto.java` y `ProductoService` (`POST /products`).
2. **Un producto obligatorio por competidor:** `Competitor.producto`, `Validation.competitor` y consulta de existencia en `LabRepository.createCompetitor`.
3. **Listar productos:** `GET /products`, consulta JPQL de `Producto`.
4. **Nombres que empiezan por A:** `GET /competitors/names/start-with-a`, consulta JPQL `LIKE :prefix` y proyección de nombres.

El objetivo de servicio cloud quedó comprobado contra MongoDB Atlas real, clúster `cluster0.keens7w.mongodb.net`, base `ArquiSW`. La evidencia cloud está separada de la local en `docs/evidencia-cloud/`. No se incluyen credenciales. El ZIP se puede entregar en Moodle; la carga no se realizó desde esta aplicación.

## Evidencia cloud final

El recorrido crea `Producto` y tres competidores mediante HTTP y persistencia JPA. Comprueba la asociación obligatoria, el vehículo embebido, las consultas y los rechazos de datos inválidos. Después detiene y reinicia su propia API; verifica nuevamente los IDs y la fecha de compra, y consulta los documentos reales de Atlas mediante el verificador BSON de lectura.

- `evidencia-cloud/resultado.json`: 31 comprobaciones, reinicio PASS y BSON PASS, con fecha y clúster.
- `evidencia-cloud/pruebas-http.txt`: salida de las comprobaciones.
- `evidencia-cloud/documentos-bson.txt`: documentos persistidos de prueba, sin cadena de conexión ni contraseña.
- `evidencia-cloud/servidor-pruebas.log`: diagnóstico del servidor, sin contraseña.

Los registros de ensayo se conservan en `ArquiSW` para que el docente pueda contrastarlos con Atlas Data Explorer. La API temporal de la batería se detuvo al finalizar.
