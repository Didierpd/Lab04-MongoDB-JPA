# README del proyecto base (resumen de procedencia)

Origen: https://github.com/gpedrazag/Lab-DespliegueCloud
Commit: 3cb56ba567de62a641adf75bc142bbca55a4d7c0

El proyecto original es una plantilla JAX-RS con servidor Jetty embebido. Su README indica `mvn clean install` y `java -cp target/classes:target/dependency/* com.example.Main`. El repositorio base usa Competitor y PostgreSQL; esta entrega adapta la persistencia a MongoDB según la guía lab04_MongoDB-2019-1.pdf. Se conserva el reconocimiento de procedencia; no se atribuye al estudiante la autoría del código base del docente.
