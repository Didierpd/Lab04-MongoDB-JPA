package com.example.persistence;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import org.bson.types.ObjectId;

/** Read-only BSON verification of records created through the HTTP/JPA API. */
public final class MongoEvidence {
    public static void main(String[] args) {
        if (args.length != 2) throw new IllegalArgumentException("competitorId productId");
        try {
            MongoDatabase db = MongoRuntime.client().getDatabase(MongoRuntime.database()).withCodecRegistry(com.mongodb.MongoClient.getDefaultCodecRegistry());
            Document c=db.getCollection("COMPETITOR").find(Filters.or(Filters.eq("_id",args[0]),Filters.eq("_id",new ObjectId(args[0])))).first();
            Document p=db.getCollection("PRODUCTO").find(Filters.or(Filters.eq("_id",args[1]),Filters.eq("_id",new ObjectId(args[1])))).first();
            if(c==null || p==null) throw new AssertionError("Documentos no persistidos");
            System.out.println("COMPETITOR BSON: "+c.toJson());
            System.out.println("PRODUCTO BSON: "+p.toJson());
            Object vehicle=c.get("vehicle"); if(vehicle==null) vehicle=c.get("VEHICLE");
            if (vehicle instanceof java.util.List) {
                java.util.List<?> embedded=(java.util.List<?>)vehicle;
                if (embedded.size()!=1) throw new AssertionError("Vehicle debe contener un solo valor");
                vehicle=embedded.get(0);
            }
            if(!(vehicle instanceof Document)) throw new AssertionError("Vehicle no está embebido");
            Object fk=c.get("productoId");
            if(!new ObjectId(args[1]).equals(fk) && !args[1].equals(fk)) throw new AssertionError("Referencia de producto incorrecta");
            System.out.println("OK: documentos reales, vehículo embebido y referencia de producto.");
        } finally { MongoRuntime.close(); }
    }
}
