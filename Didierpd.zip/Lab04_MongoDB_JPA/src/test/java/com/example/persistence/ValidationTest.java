package com.example.persistence;
import com.example.models.*;
import java.time.Instant;
import javax.ws.rs.BadRequestException;
import org.junit.Test;
import static org.junit.Assert.*;
public class ValidationTest {
    private CompetitorDTO valid() { CompetitorDTO d=new CompetitorDTO();d.setName(" Ana ");d.setSurname("Perez");d.setAge(20);d.setProductoId("507f1f77bcf86cd799439011");return d; }
    @Test public void acceptsLeapDay() { assertEquals(Instant.parse("2024-02-29T00:00:00Z"),Validation.date("2024-02-29").toInstant()); }
    @Test(expected=BadRequestException.class) public void rejectsImpossibleDate() { Validation.date("2025-02-29"); }
    @Test(expected=BadRequestException.class) public void rejectsNonIsoDate() { Validation.date("1/2/2026"); }
    @Test(expected=BadRequestException.class) public void requiresProduct() { CompetitorDTO d=valid();d.setProductoId(null);Validation.competitor(d,false); }
    @Test(expected=BadRequestException.class) public void validatesObjectId() { Validation.id("not-an-id"); }
    @Test(expected=BadRequestException.class) public void requiresVehicleOnVehicleRoute() { Validation.competitor(valid(),true); }
    @Test(expected=BadRequestException.class) public void rejectsMissingAge() { CompetitorDTO d=valid();d.setAge(null);Validation.competitor(d,false); }
    @Test(expected=BadRequestException.class) public void rejectsNegativeAge() { CompetitorDTO d=valid();d.setAge(-1);Validation.competitor(d,false); }
    @Test(expected=BadRequestException.class) public void rejectsInvalidVehicleYear() { CompetitorDTO d=valid();Vehicle v=new Vehicle();v.setPlate("TRE-465");v.setBrand("BMW");v.setModelYear(345);d.setVehicle(v);Validation.competitor(d,true); }
    @Test public void permitsOptionalVehicleAndTrimsName() { CompetitorDTO d=valid();Validation.competitor(d,false);assertEquals("Ana",d.getName()); }
}
