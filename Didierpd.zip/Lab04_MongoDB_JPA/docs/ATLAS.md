# Conexión cloud — MongoDB Atlas

Estado de esta entrega: **Atlas verificado** en el clúster `cluster0.keens7w.mongodb.net`, base `ArquiSW`. El usuario creó el clúster y configuró sus credenciales mediante diálogo privado. Pasaron las 31 comprobaciones HTTP, la relectura tras reiniciar y la verificación BSON. Resultado y evidencia en `evidencia-cloud/resultado.json`, `pruebas-http.txt` y `documentos-bson.txt`. La configuración privada está en `.env` con permisos 600 y no forma parte de la entrega.

1. En tu cuenta de Atlas, crear o seleccionar un clúster para el laboratorio. Revisar en la consola las condiciones y costes de la opción elegida antes de contratarla.
2. Crear un **usuario de base de datos** con lectura/escritura en `ArquiSW`; no usar la contraseña de acceso a la web de Atlas como contraseña de MongoDB.
3. Añadir a la lista de acceso la IP pública desde la que se ejecutará Java.
4. En **Connect → Drivers**, obtener la cadena de conexión. Utilizar el formato de URI que acepte el driver incluido y conservar las opciones de TLS y autenticación. El adaptador admite `mongodb://` y `mongodb+srv://` mediante `MongoClientURI`.
5. Introducir localmente usuario/clave en la URI, codificando los caracteres reservados del usuario o contraseña con percent-encoding. No pegar claves en README, Postman ni el chat.

Ejemplo con marcadores, para configurar en una terminal local:

```bash
export MONGODB_URI='mongodb+srv://USUARIO:CLAVE_CODIFICADA@CLUSTER.mongodb.net/ArquiSW?retryWrites=true&w=majority'
export MONGODB_DATABASE='ArquiSW'
mvn clean package
java -cp 'target/classes:target/dependency/*' com.example.Main
```

La URI es solo un ejemplo: sustituirla por la proporcionada por el clúster. Otra opción es copiar `.env.example` a `.env`, editarlo localmente y cargar **solo ese archivo de confianza**: `set -a; . ./.env; set +a`. `.env` está excluido de Git y del ZIP.

## Verificar el objetivo cloud

```bash
mvn test-compile package
python3 scripts/pruebas_integracion.py --cloud
```

El modo cloud usa `MONGODB_URI` y `MONGODB_DATABASE` configurados, crea registros identificables en esa base y arranca su propia API en localhost. No modifica reglas de red ni usuarios de Atlas. Conserva las pruebas y escribe el resultado en `docs/evidencia-cloud/`.

Para la entrega, guardar: respuesta 201 del producto, respuesta 201 del competidor con vehículo, resultado de GET `/products`, resultado del filtro con A, y captura de las colecciones `PRODUCTO`/`COMPETITOR` en Data Explorer con los mismos IDs. Ocultar datos de acceso. Reabrir la API y confirmar que los registros siguen en Atlas.

El acceso requiere red, permisos del usuario de base de datos y TLS/SNI. Si no inicia, revisar DNS SRV, lista de IP, nombre de base, contraseña codificada y versión de Java. La rama EclipseLink 2.x y el driver 3.x se mantienen aquí por el objetivo académico; esta entrega no certifica compatibilidad productiva con cualquier versión futura de Atlas. No desactivar la verificación TLS para resolver fallos.

Fuentes oficiales consultadas el 08-11-2026:

- [Conectar con drivers: TLS, SNI, IP y usuario](https://www.mongodb.com/docs/atlas/driver-connection/).
- [Usuarios de base de datos](https://www.mongodb.com/docs/atlas/security-add-mongodb-users/).
- [Lista de acceso por IP](https://www.mongodb.com/docs/atlas/security/ip-access-list/).
- [EclipseLink: mapeos NoSQL, relaciones externas y documentos embebidos](https://eclipse.dev/eclipselink/documentation/2.5/solutions/nonrelational_db002.htm).

## Configurar mediante diálogo privado

En un equipo Linux con Zenity, se puede introducir el usuario y la contraseña en ventanas locales. La contraseña se oculta, se codifica para la URI y se guarda en `.env` con permisos 600, fuera de Git y del ZIP. Sin interfaz gráfica, el script utiliza una terminal con entrada de contraseña oculta.

```bash
python3 scripts/configurar_atlas.py --host TU_CLUSTER.mongodb.net --probar
# Para seleccionar Java:
python3 scripts/configurar_atlas.py --host TU_CLUSTER.mongodb.net --probar --java /ruta/jdk8/bin/java
```

`--probar` ejecuta la batería HTTP contra Atlas, reinicia su propia API y comprueba el BSON persistido. Si falla, revisar la evidencia antes de declarar cumplido el objetivo cloud.

## Repetir la prueba con la configuración ya guardada

```bash
python3 scripts/probar_atlas_guardado.py --java /ruta/jdk8/bin/java
```

El script lee únicamente las variables permitidas de `.env` sin ejecutar comandos de ese archivo. `--diagnostico` permite comprobar la conexión y mostrar solo categorías/códigos de error. Las credenciales del equipo se mantienen fuera del ZIP.
