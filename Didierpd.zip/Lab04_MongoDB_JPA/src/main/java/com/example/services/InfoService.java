package com.example.services;
import java.util.*;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
@Path("/")
public class InfoService {
    @GET @Produces(MediaType.APPLICATION_JSON)
    public Map<String,Object> info() {
        Map<String,Object> m = new LinkedHashMap<>(); m.put("laboratorio","MongoDB con JPA / EclipseLink NoSQL");
        m.put("rutas",Arrays.asList("POST /products", "GET /products", "POST /competitors/add", "POST /competitors/vehicle", "GET /competitors", "GET /competitors/{name}", "GET /competitors/names/start-with-a")); return m;
    }
}
