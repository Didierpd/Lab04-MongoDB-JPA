package com.example.persistence;

import javax.resource.cci.ConnectionFactory;
import org.eclipse.persistence.nosql.adapters.mongo.Mongo3ConnectionSpec;
import org.eclipse.persistence.internal.nosql.adapters.mongo.MongoDatabaseConnectionFactory;

/** Allows mongodb:// and mongodb+srv://, preserving driver TLS and authentication options. */
public class UriMongoConnectionSpec extends Mongo3ConnectionSpec {
    @Override
    protected ConnectionFactory createMongoConnectionFactory() {
        return new MongoDatabaseConnectionFactory(MongoRuntime.client().getDatabase(MongoRuntime.database()));
    }
}
