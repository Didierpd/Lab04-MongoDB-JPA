package com.example.models;

import javax.persistence.*;
import org.eclipse.persistence.nosql.annotations.*;

@Entity
@NoSql(dataType="COMPETITOR", dataFormat=DataFormatType.MAPPED)
public class Competitor {
    @Id @GeneratedValue @Field(name="_id")
    private String id;

    private String name;

    private String surname;

    private int age;

    private String telephone;

    private String cellphone;

    private String address;

    private String city;

    private String country;

    private boolean winner;
    @Embedded
    private Vehicle vehicle;
    @ManyToOne(optional=false, fetch=FetchType.EAGER)
    @JoinField(name="productoId")
    private Producto producto;
    @Temporal(TemporalType.TIMESTAMP)
    private java.util.Date createdAt;
    @Temporal(TemporalType.TIMESTAMP)
    private java.util.Date updatedAt;
    public Competitor() {}
    public String getId() { return id; }
    public void setId(String value) { this.id = value; }
    public String getName() { return name; }
    public void setName(String value) { this.name = value; }
    public String getSurname() { return surname; }
    public void setSurname(String value) { this.surname = value; }
    public int getAge() { return age; }
    public void setAge(int value) { this.age = value; }
    public String getTelephone() { return telephone; }
    public void setTelephone(String value) { this.telephone = value; }
    public String getCellphone() { return cellphone; }
    public void setCellphone(String value) { this.cellphone = value; }
    public String getAddress() { return address; }
    public void setAddress(String value) { this.address = value; }
    public String getCity() { return city; }
    public void setCity(String value) { this.city = value; }
    public String getCountry() { return country; }
    public void setCountry(String value) { this.country = value; }
    public boolean isWinner() { return winner; }
    public void setWinner(boolean value) { this.winner = value; }
    public Vehicle getVehicle() { return vehicle; }
    public void setVehicle(Vehicle value) { this.vehicle = value; }
    public Producto getProducto() { return producto; }
    public void setProducto(Producto value) { this.producto = value; }
    public java.util.Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(java.util.Date value) { this.createdAt = value; }
    public java.util.Date getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(java.util.Date value) { this.updatedAt = value; }
    @PrePersist
    private void beforeInsert() {
        if (producto == null) throw new IllegalStateException("Cada competidor requiere un producto.");
        createdAt = new java.util.Date(); updatedAt = createdAt;
    }
    @PreUpdate
    private void beforeUpdate() { updatedAt = new java.util.Date(); }

}
