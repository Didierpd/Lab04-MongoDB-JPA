package com.example.services;
import com.example.models.ProductoDTO;
import com.example.persistence.LabRepository;
import javax.ws.rs.*;
import javax.ws.rs.core.*;

@Path("/products") @Produces(MediaType.APPLICATION_JSON)
public class ProductoService {
    private final LabRepository repository = new LabRepository();
    @GET public Response all() { return Response.ok(repository.products()).build(); }
    @POST @Consumes(MediaType.APPLICATION_JSON)
    public Response create(ProductoDTO dto) { return Response.status(201).entity(repository.createProduct(dto)).build(); }
}
